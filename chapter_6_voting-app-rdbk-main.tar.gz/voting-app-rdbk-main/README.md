# voting-app-py
A simple python app that registers votes in a redis
